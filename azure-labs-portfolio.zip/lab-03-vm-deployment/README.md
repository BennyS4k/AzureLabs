# Lab 03 Vm Deployment

Short lab description goes here.
